The StarDict source code can be found from the StarDict project page:
http://sourceforge.net/projects/stardict/