StarDict Portable Launcher 2.4.8.1
==============================
Copyright 2004-2006 John T. Haller

Website: http://PortableApps.com/StarDictPortable

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


ABOUT StarDict PORTABLE
===================
The StarDict Portable Launcher allows you to run StarDict from a removable drive whose letter changes as you move it to another computer.  The program can be entirely self-contained on the drive and then used on any Windows computer.


LICENSE
=======
This code is released under the GPL.  The full code is included with this package as StarDictPortable.nsi.


INSTALLATION / DIRECTORY STRUCTURE
==================================
By default, the program expects one of these directory structures:

-\ <--- Directory with StarDictPortable.exe
	+\App\
		+\StarDict\
		+\gtk\
	+\Data\
		+\settings\

OR

-\ <--- Directory with StarDictPortable.exe
	+\StarDictPortable\
		+\App\
			+\StarDict\
			+\gtk\
		+\Data\
			+\settings\

OR

-\ <--- Directory with StarDictPortable.exe
	+\PortableApps\
		+\StarDictPortable\
			+\App\
				+\StarDict\
				+\gtk\
			+\Data\
				+\settings\

OR

-\ <--- Directory with StarDictPortable.exe (PortableApps, for instance)
	+\Apps\
		+\StarDictPortable\
			+\StarDict\
			+\gtk\
	+\Data\
		+\StarDictPortable\
			+\settings\


It can be used in other directory configurations by including the StarDictPortable.ini file in the same directory as StarDictPortable.exe and configuring it as details in the INI file section below.  The INI file may also be placed in a subdirectory of the directory containing StarDictPortable.exe called StarDictPortable  or 2 directories deep in PortableApps\StarDictPortable or Data\StarDictPortable.  All paths in the INI should remain relative to the EXE and not the INI.


StarDictPortable.INI CONFIGURATION
==============================
The StarDict Portable Launcher will look for an ini file called StarDictPortable.ini within its directory.  If you are happy with the default options, it is not necessary, though.  The INI file is formatted as follows:

[StarDictPortable]
StarDictDirectory=App\StarDict
GTKDirectory=App\GTK
SettingsDirectory=Data\settings
StarDictExecutable=stardict.exe
AdditionalParameters=
WaitForStarDict=false
DisableSplashScreen=false

The StarDictDirectory, GTKDirectory and SettingsDirectory entries should be set to the *relative* path to the appropriate directories from the current directory.  All must be a subdirectory (or multiple subdirectories) of the directory containing StarDictPortable.exe.  The default entries for these are described in the installation section above.

The StarDictExecutable entry allows you to set the StarDict Portable Launcher to use an alternate EXE call to launch StarDict.  This is helpful if you are using a machine that is set to deny StarDict.exe from running.  You'll need to rename the StarDict.exe file and then enter the name you gave it on the StarDictexecutable= line of the INI.

The AdditionalParameters entry allows you to pass additional commandline parameter entries to StarDict.exe.  Whatever you enter here will be appended to the call to StarDict.exe.

The WaitForStarDict entry allows you to set the StarDict Portable Launcher to wait for StarDict to close before it closes.  This option is mainly of use when StarDictPortable.exe is called by another program that awaits it's conclusion to perform a task.


PROGRAM HISTORY / ABOUT THE AUTHORS
===================================
This launcher contains elements from multiple sources.  It is loosely based on the Firefox Portable launcher and contains some ideas from mai9 and tracon on the mozillaZine forums.